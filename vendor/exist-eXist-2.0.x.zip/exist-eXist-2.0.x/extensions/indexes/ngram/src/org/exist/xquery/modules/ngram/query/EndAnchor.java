package org.exist.xquery.modules.ngram.query;

public class EndAnchor implements WildcardedExpression {

}
