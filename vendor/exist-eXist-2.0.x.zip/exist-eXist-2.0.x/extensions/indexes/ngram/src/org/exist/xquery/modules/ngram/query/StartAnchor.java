package org.exist.xquery.modules.ngram.query;

public class StartAnchor implements WildcardedExpression {

}
