package org.exist.xquery.modules.ngram.query;

public interface WildcardedExpression {
}